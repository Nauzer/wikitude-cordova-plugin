//
//  WTWikitudePlugin.h
//  Wikitude
//
//  Copyright (c) 2012 Wikitude. All rights reserved.
//

#import <Cordova/CDV.h>

@interface WTWikitudePlugin : CDVPlugin

+ (NSString *)composeFailingAPIAuthorizationMessageFromError:(NSError *)error;

@end
